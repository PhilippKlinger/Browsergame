Thanks for downloading, this font is FREE FOR PERSONAL and COMMERCIAL USE.

But If you want to DONATE click here :
https://paypal.me/rikkiibrahim .I really appreciate your donations.

visit Our Store for more amazing font :

https://www.creativefabrica.com/designer/r-studio/ref/235552

if there are any problems or questions, please contact us by email :
rikki.ibrahim88@gmail.com

Thank you,
Best regards
R. Studio